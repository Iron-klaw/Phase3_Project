﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Project.Models
{
    public partial class Laptop
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Config { get; set; }
        public double Price { get; set; }
        public bool? Available { get; set; }
        public int Cid { get; set; }
        public int Sid { get; set; }

        public virtual User CidNavigation { get; set; }
        public virtual User SidNavigation { get; set; }
    }
}
