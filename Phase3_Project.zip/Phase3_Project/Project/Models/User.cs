﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Project.Models
{
    public partial class User
    {
        public User()
        {
            LaptopCidNavigations = new HashSet<Laptop>();
            LaptopSidNavigations = new HashSet<Laptop>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public string Contact { get; set; }

        public virtual ICollection<Laptop> LaptopCidNavigations { get; set; }
        public virtual ICollection<Laptop> LaptopSidNavigations { get; set; }
    }
}
