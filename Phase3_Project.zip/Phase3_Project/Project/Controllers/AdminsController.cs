﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Project.Models;
using Microsoft.AspNetCore.Http;

namespace Project.Controllers
{
    public class AdminsController : Controller
    {
        private readonly Phase3_DBContext _context;

        public AdminsController(Phase3_DBContext context)
        {
            _context = context;
        }

        // GET: Admins
        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Admins.Single(x => x.Email == email).Id;
            return View(await _context.Admins.ToListAsync());
        }

        // GET: Admins/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            if (id == null)
            {
                return NotFound();
            }

            var admin = await _context.Admins
                .FirstOrDefaultAsync(m => m.Id == id);
            if (admin == null)
            {
                return NotFound();
            }

            return View(admin);
        }

        // GET: Admins/Create
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            return View();
        }

        // POST: Admins/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Email,Password")] Admin admin)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            if (ModelState.IsValid)
            {
                _context.Add(admin);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(admin);
        }

        // GET: Admins/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            if (id == null)
            {
                return NotFound();
            }

            var admin = await _context.Admins.FindAsync(id);
            if (admin == null)
            {
                return NotFound();
            }
            return View(admin);
        }

        // POST: Admins/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Email,Password")] Admin admin)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            if (id != admin.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(admin);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AdminExists(admin.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(admin);
        }

        // GET: Admins/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            if (id == null)
            {
                return NotFound();
            }

            var admin = await _context.Admins
                .FirstOrDefaultAsync(m => m.Id == id);
            if (admin == null)
            {
                return NotFound();
            }

            return View(admin);
        }

        // POST: Admins/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            var admin = await _context.Admins.FindAsync(id);
            _context.Admins.Remove(admin);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        //=================================================================================
        private bool AdminExists(int id)
        {
            return _context.Admins.Any(e => e.Id == id);
        }
        public bool validateUser(string email, string password)
        {
            List<Admin> users = _context.Admins.ToList();
            return users.Exists(x => x.Email == email && x.Password == password);
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(Admin admin)
        {
            if (validateUser(admin.Email, admin.Password))
            {

                HttpContext.Session.SetString("email", admin.Email);
                return RedirectToAction("Index", "Admins");
            }
            else
                ViewBag.msg = "Invalid input credentials...";
            return View();
        }
        //GET all Available Laptops
        public IActionResult GetAvailableLaptop()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Admins.Single(x => x.Email == email).Id;
            var Phase3_DBContext = _context.Laptops.Include(t => t.CidNavigation).Include(t => t.SidNavigation);
            List<Laptop> laptops = Phase3_DBContext.ToList();
            laptops = laptops.FindAll(x => x.Available == true);
            return View(laptops);
        }
        //GET all Sold Laptops
        public IActionResult GetSoldLaptop()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Admins.Single(x => x.Email == email).Id;
            var Phase3_DBContext = _context.Laptops.Include(t => t.CidNavigation).Include(t => t.SidNavigation);
            List<Laptop> laptops = Phase3_DBContext.ToList();
            laptops = laptops.FindAll(x => x.Available == false);
            return View(laptops);
        }
        //Get all Customers
        public IActionResult AllCustomers()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Admins.Single(x => x.Email == email).Id;
            return View(_context.Users.ToList().FindAll(x => x.Role == "customer"));
        }
        //Get all Sellers
        public IActionResult AllSellers()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Admins.Single(x => x.Email == email).Id;
            return View(_context.Users.ToList().FindAll(x => x.Role == "seller"));
        }
        //=====================================
        public async Task<IActionResult> AllUsers()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Admins.Single(x => x.Email == email).Id;

            return View(await _context.Users.ToListAsync());
        }

        // GET: Users/Details/5
        public async Task<IActionResult> UserDetails(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Admins.Single(x => x.Email == email).Id;

            if (id == null)
            {
                return NotFound();
            }

            var Users = await _context.Users
                .FirstOrDefaultAsync(m => m.Id == id);
            if (Users == null)
            {
                return NotFound();
            }

            return View(Users);
        }



        //=====================================================
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("login");
        }
    }
}
