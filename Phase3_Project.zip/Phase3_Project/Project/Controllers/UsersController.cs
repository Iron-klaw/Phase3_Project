﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Project.Models;

namespace Project.Controllers
{
    public class UsersController : Controller
    {
        private readonly Phase3_DBContext _context;

        public UsersController(Phase3_DBContext context)
        {
            _context = context;
        }

        // GET: Users
        public async Task<IActionResult> Index()
        {
            return View(await _context.Users.ToListAsync());
        }

        // GET: Users/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(m => m.Id == id);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        public IActionResult AllCustomers()
        {
            return View(_context.Users.ToList().FindAll(x => x.Role == "customer"));
        }
        //Get all Sellers
        public IActionResult AllSellers()
        {
            return View(_context.Users.ToList().FindAll(x => x.Role == "seller"));
        }
        // GET: Users

        public User getByMail(string mail)
        {

            return _context.Users.Single(x => x.Email == mail);
        }
        // GET: Users/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Email,Password,Role,Contact")] User user)
        {
            if (ModelState.IsValid)
            {
                _context.Add(user);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        // GET: Users/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            if (id == null)
            {
                return NotFound();
            }

            var user = await _context.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        // POST: Users/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Email,Password,Role,Contact")] User user)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }

            if (id != user.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(user);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserExists(user.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                if (user.Role == "customer")
                {
                    return RedirectToAction(nameof(GetAvailableLaptop));
                }
                else
                {
                    return RedirectToAction(nameof(GetSoldLaptopOfSeller));
                }
            }
            return View(user);
        }

        // GET: Users/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }

            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            string role = _context.Users.Single(x => x.Email == email).Role;

            if (role != "seller")
            {
                return RedirectToAction("login");

            }

            if (id == null)
            {
                return NotFound();
            }

            var user = await _context.Laptops
                .Include(t => t.CidNavigation)
                .Include(t => t.SidNavigation)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }

            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            string role = _context.Users.Single(x => x.Email == email).Role;

            if (role != "seller")
            {
                return RedirectToAction("login");

            }
            var Laptop = await _context.Laptops.FindAsync(id);
            _context.Laptops.Remove(Laptop);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(GetSoldLaptopOfSeller));
        }

        private bool UserExists(int id)
        {
            return _context.Users.Any(e => e.Id == id);
        }

        private bool LaptopExists(int id)
        {
            return _context.Laptops.Any(e => e.Id == id);
        }

        public bool validateUser(string email, string password, string role)
        {
            List<User> users = _context.Users.ToList();
            return users.Exists(x => x.Email == email && x.Password == password && x.Role == role);
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(User user)
        {
            if (validateUser(user.Email, user.Password, user.Role))
            {
                HttpContext.Session.SetString("email", user.Email);
                if (user.Role == "seller")
                {
                    ViewBag.msg = "123";
                    return RedirectToAction("GetSoldLaptopOfSeller", "Users", new { uname = user.Name });
                }
                else
                {
                    return RedirectToAction("GetAvailableLaptop", "Users", new { uname = user.Name });
                }

            }
            else
                ViewBag.msg = "Invalid input credentials...";
            return View();
        }
        //==============================================================================================================

        public async Task<IActionResult> Purchase(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            string role = _context.Users.Single(x => x.Email == email).Role;

            if (role != "customer")
            {
                return RedirectToAction("login");

            }
            if (id == null)
            {
                return NotFound();
            }

            var Laptop = await _context.Laptops.Include(t => t.CidNavigation)
                .Include(t => t.SidNavigation)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (Laptop == null)
            {
                return NotFound();
            }

            ViewBag.gst = Laptop.Price * 0.18;
            ViewBag.total = Laptop.Price + Laptop.Price * 0.18;
            return View(Laptop);
        }
        //Order the Laptop
        public async Task<IActionResult> Order(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }

            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            string role = _context.Users.Single(x => x.Email == email).Role;

            if (role != "customer")
            {
                return RedirectToAction("login");

            }
            if (id == null)
            {
                return NotFound();
            }
            var Laptop = await _context.Laptops.FindAsync(id);
            if (Laptop == null)
            {
                return NotFound();
            }
            ViewData["Cid"] = new SelectList(_context.Users, "Id", "Id", Laptop.CidNavigation);
            ViewData["Sid"] = new SelectList(_context.Users, "Id", "Id", Laptop.SidNavigation);

            return View(Laptop);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Order(int id, [Bind("Id,Brand,Config,Price,Sid,Cid,Available")] Laptop Laptop)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            string role = _context.Users.Single(x => x.Email == email).Role;

            if (role != "customer")
            {
                return RedirectToAction("login");

            }
            User user = getByMail(email);
            if (id != Laptop.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    Laptop.CidNavigation = user;
                    Laptop.Cid = user.Id;
                    Laptop.Available = false;

                    _context.Update(Laptop);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {

                }
                return RedirectToAction(nameof(GetAvailableLaptop));
            }
            ViewBag.Cid = 2;
            ViewData["Cid"] = new SelectList(_context.Users, "Id", "Id", Laptop.CidNavigation);
            ViewData["Sid"] = new SelectList(_context.Users, "Id", "Id", Laptop.SidNavigation);
            return View(Laptop);
        }




        //sold laptop of seller
        public IActionResult GetSoldLaptopOfSeller()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            User user = getByMail(email);
            if (user.Role != "seller")
            {
                return RedirectToAction("login");

            }

            if (user.Id == 0)
            {
                return RedirectToAction("login");
            }

            var digitalRetailersContext = _context.Laptops.Include(t => t.CidNavigation).Include(t => t.SidNavigation);
            List<Laptop> laptops = digitalRetailersContext.ToList();

            laptops = laptops.FindAll(x => x.Available == false && x.Sid == user.Id);
            return View(laptops);

        }

        //SaleReport
        public async Task<IActionResult> SaleReport(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            string role = _context.Users.Single(x => x.Email == email).Role;
            if (role != "seller")
            {
                return RedirectToAction("login");

            }

            if (id == null)
            {
                return NotFound();
            }

            var Laptop = await _context.Laptops
                .Include(t => t.CidNavigation)
                .Include(t => t.SidNavigation)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (Laptop == null)
            {
                return NotFound();
            }
            return View(Laptop);
        }
        //unsold laptop
        public IActionResult UnSoldLaptop()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            User user = getByMail(email);
            if (user.Role != "seller")
            {
                return RedirectToAction("login");

            }
            if (user.Id == 0)
            {
                return RedirectToAction("login");
            }
            var digitalRetailersContext = _context.Laptops.Include(t => t.CidNavigation).Include(t => t.SidNavigation);
            List<Laptop> laptops = digitalRetailersContext.ToList();

            laptops = laptops.FindAll(x => x.Available == true && x.SidNavigation.Id == user.Id);
            return View(laptops);

        }
        //Adding new laptop by seller
        public IActionResult AddNewlaptop()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            string role = _context.Users.Single(x => x.Email == email).Role;
            if (role != "seller")
            {
                return RedirectToAction("login");

            }
            return View();
        }

        // POST: Laptops/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddNewlaptop([Bind("Id,Name,Config,Price,Sid,Cid,Available")] Laptop Laptop)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            User user = getByMail(email);
            if (user.Role != "seller")
            {
                return RedirectToAction("login");

            }
            if (ModelState.IsValid)
            {
                if (email == null) { }
                else
                {
                    Laptop.SidNavigation = user;
                    Laptop.Sid = user.Id;

                    _context.Add(Laptop);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(GetSoldLaptopOfSeller));
                }
            }

            return View(Laptop);
        }

        //GET all Available Laptops
        public IActionResult GetAvailableLaptop()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            string role = _context.Users.Single(x => x.Email == email).Role;
            if (role != "customer")
            {
                return RedirectToAction("login");

            }
            var digitalRetailersContext = _context.Laptops.Include(t => t.CidNavigation).Include(t => t.SidNavigation);
            List<Laptop> laptops = digitalRetailersContext.ToList();
            laptops = laptops.FindAll(x => x.Available == true);
            return View(laptops);
        }


        public IActionResult PurchasedLaptop()
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }
            string email = HttpContext.Session.GetString("email");

            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            string role = _context.Users.Single(x => x.Email == email).Role;

            if (role != "customer")
            {
                return RedirectToAction("login");

            }
            User user = getByMail(email);
            if (user.Id == 0)
            {
                return RedirectToAction("login");
            }
            var digitalRetailersContext = _context.Laptops.Include(t => t.CidNavigation).Include(t => t.SidNavigation);
            List<Laptop> laptops = digitalRetailersContext.ToList();

            laptops = laptops.FindAll(x => x.Available == false && x.CidNavigation.Id == user.Id);
            return View(laptops);

        }

        //SaleReport
        public async Task<IActionResult> purchaseReport(int? id)
        {
            if (HttpContext.Session.GetString("email") == null)
            {
                return RedirectToAction("login");
            }

            string email = HttpContext.Session.GetString("email");
            ViewBag.id = _context.Users.Single(x => x.Email == email).Id;
            string role = _context.Users.Single(x => x.Email == email).Role;

            if (role != "customer")
            {
                return RedirectToAction("login");

            }
            if (id == null)
            {
                return NotFound();
            }

            var Laptop = await _context.Laptops
                .Include(t => t.CidNavigation)
                .Include(t => t.SidNavigation)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (Laptop == null)
            {
                return NotFound();
            }
            return View(Laptop);
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("login");
        }
    }
}
