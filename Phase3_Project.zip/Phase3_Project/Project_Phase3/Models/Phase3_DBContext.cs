﻿using Microsoft.EntityFrameworkCore;
using Project_Phase3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Phase3.Models
{
    public static class ModelBuilderExtensions
    {
        public static void SeedAdmins(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>().HasData(
                new Admin { a_id = 101, a_name = "Amith", a_password = "amith", a_contact = "987654321", a_email = "amith@gmail.com" },
                new Admin { a_id = 102, a_name = "Akash", a_password = "akash", a_contact = "923456781", a_email = "akash@gmail.com" },
                new Admin { a_id = 103, a_name = "Chitra", a_password = "chitra", a_contact = "987123456", a_email = "chitra@gmail.com" }
                );
        }
    }
    public class Phase3_DBContext : DbContext
    {
        public Phase3_DBContext(DbContextOptions<Phase3_DBContext> options) : base(options)
        {

        }
        public DbSet<AvailableLaptop> AvailableLaptop { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Seller> Sellers { get; set; }
        public DbSet<Laptop> Laptop { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.SeedAdmins();
        }
    }

}

