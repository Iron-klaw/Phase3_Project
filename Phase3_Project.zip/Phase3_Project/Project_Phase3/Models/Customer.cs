﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Phase3.Models
{
    public class Customer
    {
        public Customer()
        {
            Laptop = new HashSet<Laptop>();
        }

        [Key]
        public int c_id { get; set; }
        public string c_name { get; set; }
        public string c_pass { get; set; }
        public string c_contact { get; set; }
        public string c_email { get; set; }

        public virtual ICollection<Laptop> Laptop { get; set; }
    }
}

