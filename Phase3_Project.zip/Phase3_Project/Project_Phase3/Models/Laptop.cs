﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Phase3.Models
{
    public class Laptop
    {
        [Key]
        public int o_id { get; set; }
        public int? l_id { get; set; }
        public int? seller_id { get; set; }
        public int? customer_Id { get; set; }

        public virtual Customer Customer { get; set; }
        public virtual AvailableLaptop L { get; set; }
        public virtual Seller Seller { get; set; }
    }
}
