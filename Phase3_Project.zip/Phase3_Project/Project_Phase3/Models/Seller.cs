﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Phase3.Models
{
    public class Seller
    {
        public Seller()
        {
            AvailableLaptop = new HashSet<AvailableLaptop>();
            Laptop = new HashSet<Laptop>();
        }

        [Key]
        public int s_id { get; set; }
        public string s_name { get; set; }
        public string s_pass { get; set; }
        public string s_contact { get; set; }
        public string s_email { get; set; }

        public virtual ICollection<AvailableLaptop> AvailableLaptop { get; set; }
        public virtual ICollection<Laptop> Laptop { get; set; }
    }
}
