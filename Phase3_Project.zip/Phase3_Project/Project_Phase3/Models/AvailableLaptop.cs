﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Project_Phase3.Models
{
    public class AvailableLaptop
    {
        public AvailableLaptop()
        {
            Laptop = new HashSet<Laptop>();
        }

        [Key]
        public int l_id { get; set; }
        public int? seller_id { get; set; }
        public string l_name { get; set; }
        public string l_model { get; set; }
        public double? l_price { get; set; }

        public virtual Seller Seller { get; set; }
        public virtual ICollection<Laptop> Laptop { get; set; }
    }
}
