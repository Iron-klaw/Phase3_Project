﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Project_Phase3.Migrations
{
    public partial class mig1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Admins",
                columns: table => new
                {
                    a_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    a_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    a_password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    a_contact = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    a_email = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Admins", x => x.a_id);
                });

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    c_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    c_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_pass = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_contact = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_email = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.c_id);
                });

            migrationBuilder.CreateTable(
                name: "Sellers",
                columns: table => new
                {
                    s_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    s_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    s_pass = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    s_contact = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    s_email = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sellers", x => x.s_id);
                });

            migrationBuilder.CreateTable(
                name: "AvailableLaptop",
                columns: table => new
                {
                    l_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    seller_id = table.Column<int>(type: "int", nullable: true),
                    l_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    l_model = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    l_price = table.Column<double>(type: "float", nullable: true),
                    Sellers_id = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AvailableLaptop", x => x.l_id);
                    table.ForeignKey(
                        name: "FK_AvailableLaptop_Sellers_Sellers_id",
                        column: x => x.Sellers_id,
                        principalTable: "Sellers",
                        principalColumn: "s_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Laptop",
                columns: table => new
                {
                    o_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    l_id = table.Column<int>(type: "int", nullable: true),
                    seller_id = table.Column<int>(type: "int", nullable: true),
                    customer_Id = table.Column<int>(type: "int", nullable: true),
                    Customerc_id = table.Column<int>(type: "int", nullable: true),
                    l_id1 = table.Column<int>(type: "int", nullable: true),
                    Sellers_id = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Laptop", x => x.o_id);
                    table.ForeignKey(
                        name: "FK_Laptop_AvailableLaptop_l_id1",
                        column: x => x.l_id1,
                        principalTable: "AvailableLaptop",
                        principalColumn: "l_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Laptop_Customers_Customerc_id",
                        column: x => x.Customerc_id,
                        principalTable: "Customers",
                        principalColumn: "c_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Laptop_Sellers_Sellers_id",
                        column: x => x.Sellers_id,
                        principalTable: "Sellers",
                        principalColumn: "s_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Admins",
                columns: new[] { "a_id", "a_contact", "a_email", "a_name", "a_password" },
                values: new object[] { 101, "987654321", "amith@gmail.com", "Amith", "amith" });

            migrationBuilder.InsertData(
                table: "Admins",
                columns: new[] { "a_id", "a_contact", "a_email", "a_name", "a_password" },
                values: new object[] { 102, "923456781", "akash@gmail.com", "Akash", "akash" });

            migrationBuilder.InsertData(
                table: "Admins",
                columns: new[] { "a_id", "a_contact", "a_email", "a_name", "a_password" },
                values: new object[] { 103, "987123456", "chitra@gmail.com", "Chitra", "chitra" });

            migrationBuilder.CreateIndex(
                name: "IX_AvailableLaptop_Sellers_id",
                table: "AvailableLaptop",
                column: "Sellers_id");

            migrationBuilder.CreateIndex(
                name: "IX_Laptop_Customerc_id",
                table: "Laptop",
                column: "Customerc_id");

            migrationBuilder.CreateIndex(
                name: "IX_Laptop_l_id1",
                table: "Laptop",
                column: "l_id1");

            migrationBuilder.CreateIndex(
                name: "IX_Laptop_Sellers_id",
                table: "Laptop",
                column: "Sellers_id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Admins");

            migrationBuilder.DropTable(
                name: "Laptop");

            migrationBuilder.DropTable(
                name: "AvailableLaptop");

            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.DropTable(
                name: "Sellers");
        }
    }
}
